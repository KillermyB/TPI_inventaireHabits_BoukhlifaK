//
//  User.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/12/21.
//

import Foundation

struct User{
    
    var uid = ""
    var name: String
    var email: String
    var profilePicture: String
    
    var json: [String: Any] {
      return [
        "name": self.name,
        "email": self.email,
        "profilePicture": self.profilePicture
      ]
    }
    
    init(name: String, email: String, profilePicture: String){
        self.name = name
        self.email = email
        self.profilePicture = profilePicture
    }
    
    init(data: [String: Any], uid: String){
        self.uid = uid
        self.name = data["name"] as! String
        self.email = data["email"] as! String
        self.profilePicture = data["profilePicture"] as! String
    }
}
