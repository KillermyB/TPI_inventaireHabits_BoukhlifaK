//
//  DataServices.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/12/21.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class DataServices{
    
    private let db = Firestore.firestore()
    static let shared = DataServices()

    private init(){}

}
