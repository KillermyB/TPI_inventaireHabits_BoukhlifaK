//
//  UserServices.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/12/21.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class UserServices{
    
    private let db = Firestore.firestore()
    static let shared = UserServices()

    private init(){}
    
    func getUser(uid:String, completion: @escaping (_ error: String? , _ user: User?) -> ()){
        db.collection("Users").document(uid).getDocument { (snapShot, error) in
            if let err = error{
                completion(err.localizedDescription,nil)
            }else if let data = snapShot?.data(){
                completion(nil,User(data: data, uid: Auth.auth().currentUser!.uid))
            }
        }
    }
}
