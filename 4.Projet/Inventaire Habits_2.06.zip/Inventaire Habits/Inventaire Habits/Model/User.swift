//
//  User.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   : 12.05.2021
//Description : Mise en structure des informations pour un utilisateur pour permettre la communication avec la table crée dans Firebase
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import Foundation

//Structuring of the information stored for a user in order to be able to directly call t_user thereafter to allow the management of json files, Initialization of the types of fields required for storage.
struct t_user{
    
    var idUser = ""
    var useName: String
    var useEmail: String
    var useProfilePicture: String
    
    var json: [String: Any] {
      return [
        "useName": self.useName,
        "useEmail": self.useEmail,
        "useProfilePicture": self.useProfilePicture
      ]
    }
    //Initializing a user's type
    init(useName: String, useEmail: String, useProfilePicture: String){
        self.useName = useName
        self.useEmail = useEmail
        self.useProfilePicture = useProfilePicture
    }
    //Initializing a user's data
    init(data: [String: Any], uid: String){
        self.idUser = uid
        self.useName = data["useName"] as! String
        self.useEmail = data["useEmail"] as! String
        self.useProfilePicture = data["useProfilePicture"] as! String
    }
}
