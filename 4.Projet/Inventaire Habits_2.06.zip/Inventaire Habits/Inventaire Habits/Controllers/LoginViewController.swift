//
//  LoginViewController.swift
//  Inventaire Habits
///ETML
//Auteur : Boukhlifa Killermy
//Date   :17.05.2021
//Description : Contrôleur de la page de connexion de l'application.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import UIKit
import MBProgressHUD

class LoginViewController: UIViewController {
    //Add custom text field from Utilities : Designables
    @IBOutlet weak var email: DesignableUITextField!
    @IBOutlet weak var password: DesignableUITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    // Compare the connection information with those stored on Firestore and validate the connection information to see if a field is empty
    @IBAction func login(_ sender: Any) {
        if let email = self.email.text, let password = self.password.text{
            if email != "" && password != ""
            { //MBProgessHUD : Framework indicating to the user that the application is working with a spinner
                MBProgressHUD.showAdded(to: self.view, animated: true)
                UserServices.shared.signIn(email: email, password: password) { (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Erreur", message: error) { (_) in }
                    }else{
                        self.performSegue(withIdentifier: "home", sender: nil)
                    }
                }
            }else{
                self.showAlert(title: "Erreur", message: "Veuillez remplir tout les champs") { (_) in }
            }
        }
    }//End of function login

}//End of class LoginViewController
