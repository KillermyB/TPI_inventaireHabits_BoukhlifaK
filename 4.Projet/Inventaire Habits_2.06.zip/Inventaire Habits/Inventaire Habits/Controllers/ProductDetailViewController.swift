//
//  ProductDetailViewController.swift
//  Inventaire Habits
//
//Auteur : Boukhlifa Killermy
//Date   : 26.05.2021
//Description : Contrôleur de la page détails d'un article.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.
import UIKit
import SDWebImage

class ProductDetailViewController: UIViewController, fillData {
    
    func fill(product: t_product) {
        self.product = product
        self.setup()
    }
    
    @IBOutlet weak var img: RoundableImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var size: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var shop: UILabel!
    @IBOutlet weak var condition: UILabel!
    
    var product: t_product!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
    }
    //Setting up the data and filling in all the fields with it
    private func setup(){
        if self.product.proPicture == ""{
            self.img.image = UIImage(named: "image")
        }else{
            self.img.sd_setImage(with: URL(string: self.product.proPicture), placeholderImage: UIImage(named: "spinner"), options: SDWebImageOptions.highPriority, context: nil)
        }
        self.name.text = self.product.proName
        self.price.text = "CHF  \(self.product.proPrice.rounded(toPlaces: 2))"
        self.size.text = "Taille: \(self.product.proSize)"
        self.shop.text = self.product.proLocation
        self.condition.text = self.product.proCondition
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        self.date.text = "Date d'achat: \(dateFormatter.string(from: self.product.proDate.dateValue()))"
        
    }
    //Passing data to next screen to open
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "edit"{
            let vc = segue.destination as! EditProductViewController
            vc.product =  self.product
            vc.del = self
        }
    }
    //Sharing the data in proper format using activity controller
    @IBAction func share(_ sender: Any) {
        var text = ""
        var total = 0.0
            total = total + self.product.proPrice
        text = text + "Article: \(self.product.proName) Taille: \(self.product.proSize) Condition: \(self.product.proCondition) Lieu d'achat: \(self.product.proLocation) Prix: CHF \(self.product.proPrice)\n"
        text = text + "\n       Total: CHF \(total)"
        let items = [text]
        let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
        self.present(ac, animated: true)
    }
    //Button action that redirects to the home page
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
