//
//  LaunchViewController.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   :10.05.2021
//Description : Contrôleur de la page de lancement de l'application.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.


import UIKit
//Import the module of FirebaseAuth
import FirebaseAuth

class LaunchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.setup()
    }
    //Here we check if the user is already logged in, if the user is already logged in, he is directly redirected to the main page of the application otherwise he is returned to the login page of the application
    private func setup(){
        if Auth.auth().currentUser == nil{
            self.performSegue(withIdentifier: "login", sender: nil)
        }else{
            UserServices.shared.getUser(uid: Auth.auth().currentUser!.uid) { (error, user) in
                if let error = error{
                    self.showAlert(title: "Erreur", message: error) { (_) in
                        self.performSegue(withIdentifier: "login", sender: nil)
                    }
                }else if let user = user{
                    StaticLinker.user = user
                    self.performSegue(withIdentifier: "home", sender: nil)
                }else{
                    self.showAlert(title: "Erreur", message: "L'utilisateur n'existe pas") { (_) in
                        self.performSegue(withIdentifier: "login", sender: nil)
                    }
                }
            }
        }
    }//End of setup Function

}//End of class LaunchViewController
