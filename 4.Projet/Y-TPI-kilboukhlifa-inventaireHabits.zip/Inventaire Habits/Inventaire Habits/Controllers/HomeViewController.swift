//
//  ViewController.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   :12.05.2021
//Description : Contrôleur de la page principale de l'application
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import UIKit
//Imported frameworkd : DropdownMenu
import DropDown
import MBProgressHUD
import SDWebImage

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var colv: UICollectionView!
    //Add custom button from Utilities : Designables
    @IBOutlet weak var menuBtn: DesignableUIButton!
    @IBOutlet weak var img: UIImageView!
    //Configuration of the drop-down menu
    private var dropDown = DropDown()
    private var selectedIndex = [Int]()
    private var selectedCategory = 0
    private var allItems = [t_product]()
    private var items = [t_product]()
    private var selectedItem: t_product!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.fillUI()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detail"{
            let vc = segue.destination as! ProductDetailViewController
            vc.product = self.selectedItem
        }
    }
    //Setting the user profile image
    private func fillUI(){
        if StaticLinker.user.useProfilePicture == ""{
            self.img.image = UIImage(systemName: "person.circle")
        }else{
            self.img.sd_setImage(with: URL(string: StaticLinker.user.useProfilePicture), completed: nil)
        }
    }
    
    private func setup(){
        self.colv.delegate = self
        self.colv.dataSource = self
        self.colv.reloadData()
        //Setting up the drop down list
        self.menuBtn.setTitle("  All     ", for: .normal)
        self.dropDown.anchorView = self.menuBtn
        self.dropDown.dataSource = ["All", "Hoodie", "Tee", "Pant", "Accesories", "Jacket", "Shoes"]
        self.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.menuBtn.setTitle("  \(item)     ", for: .normal)
            self.selectedCategory = index
            self.sortFilterData(field: self.dropDown.dataSource[self.selectedCategory])
        }
        self.getData()
    }
    //Getting the required data from firebase to populate in the tableview
    private func getData(){
        MBProgressHUD.showAdded(to: self.view, animated: true)
        DataServices.shared.getProducts { (error, products) in
            MBProgressHUD.hide(for: self.view, animated: true)
            if let error = error{
                self.showAlert(title: "Erreur", message: error) { (_) in }
            }else if let products = products{
                self.allItems = products
                StaticLinker.products = products
                self.sortFilterData(field: self.dropDown.dataSource[self.selectedCategory])
            }
        }
    }
    //Sorting data according to the filter value selected
    private func sortFilterData(field: String){
        if field == "All"{
            self.items = self.allItems
            self.items.sort(by: {$0.proDate.dateValue() < $1.proDate.dateValue()})
            self.colv.reloadData()
        }else{
            self.items = self.allItems.filter({$0.proCategory == field})
            self.items.sort(by: {$0.proDate.dateValue() < $1.proDate.dateValue()})
            self.colv.reloadData()
        }
    }
    //Sharing the data is proper format using activity controller
    @IBAction func share(_ sender: Any) {
        if self.selectedIndex.count == 0{
            return
        }
        var text = ""
        var total = 0.0
        for i in self.selectedIndex{
            total = total + self.items[i].proPrice
            text = text + "Article: \(self.items[i].proName) Taille: \(self.items[i].proSize) Condition: \(self.items[i].proCondition) Lieu d'achat: \(self.items[i].proLocation) Prix: CHF \(self.items[i].proPrice)\n"
        }
        text = text + "\n       Total: CHF \(total)"
        let items = [text]
        let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
        self.present(ac, animated: true)
    }
    //Multiple selection on/off
    @IBAction func selection(_ sender: Any) {
        self.colv.allowsMultipleSelection = !self.colv.allowsMultipleSelection
        self.selectedIndex.removeAll()
        self.colv.reloadData()
    }
    //Show the drop down
    @IBAction func menu(_ sender: Any) {
        self.dropDown.show()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.items.count
    }
    //Setting up the collcetionview cells
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as! ItemsCollectionViewCell
        cell.selectImg.isHidden = !collectionView.allowsMultipleSelection
        if self.selectedIndex.contains(indexPath.row){
            cell.selectImg.tintColor = .green
        }else{
            cell.selectImg.tintColor = .purple
        }
        let text = "\(self.items[indexPath.row].proName)\nCHF \(self.items[indexPath.row].proPrice.rounded(toPlaces: 2))"
        cell.lbl.text = text
        if self.items[indexPath.row].proPicture == ""{
            cell.img.image = UIImage(named: "image")
        }else{
            cell.img.sd_setImage(with: URL(string: self.items[indexPath.row].proPicture), completed: nil)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.view.bounds.width/2)-15, height: ((self.view.bounds.width/2)-30)*1.5)
    }
    //Handling the selection and multiple selection
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if self.colv.allowsMultipleSelection{
            if self.selectedIndex.contains(indexPath.row){
                self.selectedIndex.removeAll(where: {$0 == indexPath.row})
            }else{
                self.selectedIndex.append(indexPath.row)
            }
            collectionView.reloadItems(at: [indexPath])
        }else{
            self.selectedItem = self.items[indexPath.row]
            self.performSegue(withIdentifier: "detail", sender: nil)
        }
    }

}

