//
//  ProfileViewController.swift
//  Inventaire Habits
//
//Auteur : Boukhlifa Killermy
//Date   :27.05.2021
//Description : Contrôleur de la page profil.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import UIKit
import MBProgressHUD
import FirebaseAuth
import MobileCoreServices

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    //Add custom image field from Utilities : Designables
    @IBOutlet weak var img: RoundableImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var itemsCollected: UILabel!
    
    private var image: UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
    }
    //Populating the data and assigning the delegates
    private func setup(){
        self.name.text = StaticLinker.user.useName
        self.email.text = StaticLinker.user.useEmail
        var total = 0.0
        if let products = StaticLinker.products{
            for i in products{
                total = total + i.proPrice
            }
        }
        self.price.text = "\(total.rounded(toPlaces: 2)) CHF"
        self.itemsCollected.text = "\(StaticLinker.products.count)"
        if StaticLinker.user.useProfilePicture == ""{
            self.img.image = UIImage(systemName: "person.circle")
        }else{
            self.img.sd_setImage(with: URL(string: StaticLinker.user.useProfilePicture), completed: nil)
        }
    }
    //Button action that redirects to the home page
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //Logout alert and handling
    @IBAction func logout(_ sender: Any) {
        let alert = UIAlertController(title: "Déconnexion", message: "Êtes-vous sûr de vouloir vous déconnecter ?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Oui", style: .default, handler: { (_) in
            do{
                try Auth.auth().signOut()
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "login")
                UIApplication.shared.windows.first?.rootViewController = vc
            }catch{
                self.showAlert(title: "Impossible de vous déconnecter", message: error.localizedDescription) { (_) in }
            }
        }))
        alert.addAction(UIAlertAction(title: "Non", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    //Action of the "Modifier la photo" button, opening the actionsheet for selection of where user wants to select image from camera or the gallery
    @IBAction func selectImage(_ sender: Any) {
        let optionMenu = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let galleryAction = UIAlertAction(title: "Photos", style: .default, handler: {action in
            self.library()
        })
        let cameraAction = UIAlertAction(title: "Caméra", style: .default, handler: {action in
            self.camera()
        })
        let cancelAction = UIAlertAction(title: "Annuler", style: .cancel, handler: {action in
        })
        optionMenu.addAction(galleryAction)
        optionMenu.addAction(cameraAction)
        optionMenu.addAction(cancelAction)
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = optionMenu.popoverPresentationController {
                popoverController.sourceView = self.view
                popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                popoverController.permittedArrowDirections = []
            }
        }
        self.present(optionMenu, animated: true, completion: nil)
    }
    //Open camera to take photo
    private func camera(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .camera
        imgPicker.allowsEditing = true
        self.present(imgPicker, animated: true, completion: nil)
    }
    //Open gallery to select photo
    private func library(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .photoLibrary
        imgPicker.allowsEditing = true
        self.present(imgPicker, animated: true, completion: nil)
    }
    //Selected image from camera or gallery will come here
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            self.image = image
            self.img.image = image
            self.img.contentMode = .scaleAspectFill
            self.dismiss(animated: true, completion: nil)
            MBProgressHUD.showAdded(to: self.view, animated: true)
            UserServices.shared.changeProfileImage(image: self.image) { (error) in
                MBProgressHUD.hide(for: self.view, animated: true)
                if let error = error{
                    self.setup()
                    self.showAlert(title: "Erreur", message: error) { (_) in }
                }else{
                    self.setup()
                }
            }
        }
    }
    //If user cancels selection
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

}
