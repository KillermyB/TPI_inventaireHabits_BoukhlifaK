//
//  SignUpViewController.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   :17.05.2021
//Description : Contrôleur de la page création d'un compte de l'application.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.
import UIKit
import MBProgressHUD
import MobileCoreServices

class SignUpViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    //Add custom image field from Utilities : Designables
    @IBOutlet weak var img: RoundableImageView!
    //Add custom text field from Utilities : Designables
    @IBOutlet weak var name: DesignableUITextField!
    @IBOutlet weak var email: DesignableUITextField!
    @IBOutlet weak var password: DesignableUITextField!
    
    private var image: UIImage!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //Button action that redirects to the login page
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    //Action when the user presses the login button, displays a loading spinner, retrieves the information entered and registers the user in the database by first checking for potential errors.
    @IBAction func signUp(_ sender: Any) {
        if let email = self.email.text, let password = self.password.text, let name = self.name.text{
            if email != "" && password != ""{
                MBProgressHUD.showAdded(to: self.view, animated: true)
                UserServices.shared.register(user: t_user(useName: name, useEmail: email, useProfilePicture: ""), email: email, password: password, image: self.image){ (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Erreur", message: error) { (_) in }
                    }else{
                        self.showAlert(title: "Succès", message: "Votre compte a été créer") { (_) in
                            self.performSegue(withIdentifier: "home", sender: nil)
                        }
                    }
                }
                //Error message if all fields are not filled
            }else{
                self.showAlert(title: "Erreur", message: "Veuillez remplir tout les champs" ) { (_) in }
            }
        }
    }//End of signUp function
    
    //Action of the "Ajouter une image" button, opening the actionsheet for selection of where user wants to select image from camera or the gallery
    @IBAction func selectImage(_ sender: Any) {
        let optionMenu = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let galleryAction = UIAlertAction(title: "Photos", style: .default, handler: {action in
            self.library()
        })
        let cameraAction = UIAlertAction(title: "Caméra", style: .default, handler: {action in
            self.camera()
        })
        let cancelAction = UIAlertAction(title: "Annuler", style: .cancel, handler: {action in
        })
        optionMenu.addAction(galleryAction)
        optionMenu.addAction(cameraAction)
        optionMenu.addAction(cancelAction)
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = optionMenu.popoverPresentationController {
                popoverController.sourceView = self.view
                popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                popoverController.permittedArrowDirections = []
            }
        }
        self.present(optionMenu, animated: true, completion: nil)
    }
    //Open camera to take photo
    private func camera(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .camera
        imgPicker.allowsEditing = true
        self.present(imgPicker, animated: true, completion: nil)
    }
    //Open gallery to select photo
    private func library(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .photoLibrary
        imgPicker.allowsEditing = true
        self.present(imgPicker, animated: true, completion: nil)
    }
    //Selected image from camera or gallery will come here
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            self.image = image
            self.img.image = image
            self.img.contentMode = .scaleAspectFill
            self.dismiss(animated: true, completion: nil)
        }
    }
    //if user cancels selection
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

}
