//
//  ForgotPasswordViewController.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   :17.05.2021
//Description : Contrôleur de la page réinitialisation d'un mot de passe de l'application.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.
import UIKit
import MBProgressHUD

class ForgotPasswordViewController: UIViewController {
    //Add custom text field from Utilities : Designables
    @IBOutlet weak var email: DesignableUITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    //Button action that redirects to the login page
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    //When the button is pressed check if the user write an email valid in the field
    @IBAction func reset(_ sender: Any) {
        if let email = self.email.text{
            if email != "" {
                MBProgressHUD.showAdded(to: self.view, animated: true)
                UserServices.shared.resetPassword(email: email) { (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Erreur", message: error) { (_) in }
                    }else{
                        self.showAlert(title: "Succès", message: "Veuillez vérifier vos mails afin de réinitialiser votre mot de passe") { (_) in
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
            }else{
                self.showAlert(title: "Error", message: "Veuillez saisir une adresse mail associé à un compte existant") { (_) in }
            }
        }
    }
    
}
