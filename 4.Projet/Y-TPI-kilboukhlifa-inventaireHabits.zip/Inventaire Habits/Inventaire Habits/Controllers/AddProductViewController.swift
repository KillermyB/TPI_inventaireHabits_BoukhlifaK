//
//  AddProductViewController.swift
//  Inventaire Habits
//
//Auteur : Boukhlifa Killermy
//Date   : 20.05.2021
//Description : Contrôleur de la page d'ajout d'un article.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import UIKit
//Import the framework of DropDown
import DropDown
import MBProgressHUD
import MobileCoreServices

class AddProductViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    //Add custom text field and custom image field from Utilities : Designables
    @IBOutlet weak var name: DesignableUITextField!
    @IBOutlet weak var location: DesignableUITextField!
    @IBOutlet weak var categoryField: DesignableUITextField!
    @IBOutlet weak var sizeField: DesignableUITextField!
    @IBOutlet weak var img: RoundableImageView!
    @IBOutlet weak var condition: DesignableUITextField!
    @IBOutlet weak var dateField: DesignableUITextField!
    @IBOutlet weak var price: DesignableUITextField!
    
    private var image: UIImage!
    private var selectedDate = Date()
    //Initializes categories
    private var categories = ["Hoodie", "Tee", "Pant", "Accesories", "Jacket", "Shoes"]
    //Initializes condtions
        private var conditions = ["10/10", "9/10", "8/10", "7/10", "6/10", "5/10", "4/10", "3/10", "2/10", "1/10"]
    //Initializes size
    private var size = [
        "Hoodie": ["XS", "S", "M", "L", "XL"],
        "Tee": ["XS", "S", "M", "L", "XL"],
        "Pant": ["XS", "S", "M", "L", "XL"],
        "Accesories": ["N/A"],
        "Jacket": ["XS", "S", "M", "L", "XL"],
        "Shoes": ["35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47"],
        
    ]
    //Calling dropdowns menu
    private var categoryDropDown = DropDown()
    private var sizeDropDown = DropDown()
    private var conditionDropDown = DropDown()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
    }
    
    @objc func doneButtonPressed() {
        if let  datePicker = self.dateField.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            self.selectedDate = datePicker.date
            self.dateField.text = dateFormatter.string(from: datePicker.date)
        }
        self.dateField.resignFirstResponder()
     }
    //Setting up all the dropdowns and making sure the dropdowns show data according to the categories selected
    private func setup(){
        self.condition.text = "10/10"
        self.dateField.addInputViewDatePicker(target: self, selector: #selector(doneButtonPressed))
        self.categoryField.text = "Hoodie"
        self.sizeField.text = "XS"
        self.categoryDropDown.anchorView = self.categoryField
        self.categoryDropDown.dataSource = ["Hoodie", "Tee", "Pant", "Accesories", "Jacket", "Shoes"]
        self.categoryDropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            let sizeArr = self.size[item] ?? [String]()
            if !sizeArr.contains(self.sizeField.text ?? ""){
                self.sizeField.text = sizeArr.first ?? ""
            }
            self.categoryField.text = item
            self.sizeDropDown.dataSource = sizeArr
            self.sizeDropDown.reloadAllComponents()
        }
        self.sizeDropDown.anchorView = self.sizeField
        self.sizeDropDown.dataSource = self.size[self.categoryField.text ?? ""] ?? [String]()
        self.sizeDropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.sizeField.text = item
        }
        self.conditionDropDown.anchorView = self.condition
        self.conditionDropDown.dataSource = self.conditions
        self.conditionDropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.condition.text = item
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        self.selectedDate = Date()
        self.dateField.text = dateFormatter.string(from: Date())
    }
    //Show the drop down
    @IBAction func cond(_ sender: Any) {
        self.conditionDropDown.show()
    }
    //Show the drop down
    @IBAction func cat(_ sender: Any) {
        self.categoryDropDown.show()
    }
    //Show the drop down
    @IBAction func sizeAction(_ sender: Any) {
        self.sizeDropDown.show()
    }
    //Action of the "Ajouter une image" button, opening the actionsheet for selection of where user wants to select image from camera or the gallery
    @IBAction func selectImage(_ sender: Any) {
        let optionMenu = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let galleryAction = UIAlertAction(title: "Photos", style: .default, handler: {action in
            self.library()
        })
        let cameraAction = UIAlertAction(title: "Caméra", style: .default, handler: {action in
            self.camera()
        })
        let cancelAction = UIAlertAction(title: "Annuler", style: .cancel, handler: {action in
        })
        optionMenu.addAction(galleryAction)
        optionMenu.addAction(cameraAction)
        optionMenu.addAction(cancelAction)
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = optionMenu.popoverPresentationController {
                popoverController.sourceView = self.view
                popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                popoverController.permittedArrowDirections = []
            }
        }
        self.present(optionMenu, animated: true, completion: nil)
    }
    //Open camera to take photo
    private func camera(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .camera
        self.present(imgPicker, animated: true, completion: nil)
    }
    //Open gallery to select photo
    private func library(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .photoLibrary
        self.present(imgPicker, animated: true, completion: nil)
    }
    //Selected image from camera or gallery will come here
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            self.image = image
            self.img.image = image
            self.img.contentMode = .scaleAspectFill
            self.dismiss(animated: true, completion: nil)
        }
    }
    //if user cancels selection
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    //Button that allows the validation of the data entered and ensure that the data is in the correct format  to upload them to Firebase and add to the collection of products
    @IBAction func add(_ sender: Any) {
        if let name = self.name.text, let location = self.location.text, let category = self.categoryField.text, let size = self.sizeField.text, let condition = self.condition.text, let price = self.price.text{
            if name != "" && location != "" && category != "" && size != "" && condition != "" && price != "" {
                if Double(price) == nil{
                    self.showAlert(title: "Erreur", message: "Veuillez saisir un prix valide") { (_) in }
                    return
                }
                let product = t_product(proName: name, proLocation: location, proCategory: category, proSize: size, proDate: self.selectedDate, proPrice: Double(price) ?? 0.0, proCondition: condition, proPicture: "")
                MBProgressHUD.showAdded(to: self.view, animated: true)
                DataServices.shared.addProduct(product: product, image: self.image) { (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Erreur", message: error) { (_) in }
                    }else{
                        self.showAlert(title: "Succès", message: "Article ajouté") { (_) in
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
            }else{
                self.showAlert(title: "Erreur", message: "Veuillez remplir tout les champs") { (_) in }
            }
        }
    }
    //Button action that redirects to the home page
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
