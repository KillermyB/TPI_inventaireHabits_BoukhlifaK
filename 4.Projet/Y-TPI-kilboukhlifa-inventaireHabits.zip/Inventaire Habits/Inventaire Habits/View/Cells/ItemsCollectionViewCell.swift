//
//  ItemsCollectionViewCell.swift
//  Inventaire Habits
//
//Auteur : Boukhlifa Killermy
//Date   : 20.05.2021
//Description : Cases contenant le nom, prix et image de l'article.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.
import UIKit

class ItemsCollectionViewCell: UICollectionViewCell {
    //Initialization of the elements to display in the boxes containing the articles
    @IBOutlet weak var selectImg: UIImageView!
    @IBOutlet weak var img: RoundableImageView!
    @IBOutlet weak var lbl: UILabel!
    
}
