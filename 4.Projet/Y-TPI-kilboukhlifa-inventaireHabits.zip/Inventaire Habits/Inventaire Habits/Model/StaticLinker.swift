//
//  StaticLinker.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   :19.05.2021
//Description :Mise en place du lien statique permettant l'appel depuis d'autres fonctions ou classes et qui récupère toutes les informations précédemment initialiser dans les pages Model : User et Product
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.


import Foundation
//Static link, allowing the call in other classes or functions
class StaticLinker{
    
    static var user: t_user!
    static var products: [t_product]!
    
}
