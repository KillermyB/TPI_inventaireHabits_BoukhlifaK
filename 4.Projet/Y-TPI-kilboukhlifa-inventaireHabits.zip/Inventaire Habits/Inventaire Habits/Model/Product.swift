//
//  Product.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   :19.05.2021
//Description : Mise en structure des informations pour un article pour permettre la communication avec la table crée dans Firebase
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import Foundation
//Imported module Firestore
import FirebaseFirestore
//Structuring of the information stored for an article in order to be able to directly call t_product thereafter to allow the management of json files, Initialization of the types of fields required for storage.
struct t_product{
    
    var idProduct = ""
    var fkUser: String
    var proName: String
    var proLocation: String
    var proCategory: String
    var proSize: String
    var proDate: Timestamp
    var proPrice: Double
    var proCondition: String
    var proPicture: String
    
    var json: [String: Any] {
      return [
        "fkUser": self.fkUser,
        "proName": self.proName,
        "proLocation": self.proLocation,
        "proCategory": self.proCategory,
        "proSize": self.proSize,
        "proDate": self.proDate,
        "proPrice": self.proPrice,
        "proCondition": self.proCondition,
        "proPicture": self.proPicture
      ]
    }
    //Initializing a article's type
    init(proName: String, proLocation: String, proCategory: String, proSize: String,
         proDate: Date, proPrice: Double, proCondition: String, proPicture: String){
        self.fkUser = StaticLinker.user.idUser
        self.proName = proName
        self.proLocation = proLocation
        self.proCategory = proCategory
        self.proSize = proSize
        self.proDate = Timestamp(date: proDate)
        self.proPrice = proPrice
        self.proCondition = proCondition
        self.proPicture = proPicture
    }
    //Initializing a article's type for the JSON Files
    init(data: [String: Any], id: String){
        self.idProduct = id
        self.fkUser = data["fkUser"] as! String
        self.proName = data["proName"] as! String
        self.proLocation = data["proLocation"] as! String
        self.proCategory = data["proCategory"] as! String
        self.proSize = data["proSize"] as! String
        self.proDate = data["proDate"] as! Timestamp
        self.proPrice = data["proPrice"] as! Double
        self.proCondition = data["proCondition"] as! String
        self.proPicture = data["proPicture"] as! String
    }
    
}
