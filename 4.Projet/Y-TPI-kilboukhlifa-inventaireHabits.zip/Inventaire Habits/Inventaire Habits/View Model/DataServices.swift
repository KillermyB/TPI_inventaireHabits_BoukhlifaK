//
//  DataServices.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   : 20.05.2021
//Description : Récupération des informatins de Firebase concernant l'ajout d'articles, la modification et la supression.
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import UIKit
//Importation des modules permettant d'utiliser Firebase
import Firebase
import FirebaseAuth
import FirebaseFirestore

class DataServices{
    //Link with the database
    private let db = Firestore.firestore()
    static let shared = DataServices()
//Initialisation
    private init(){}
    //Function for deleting an article, Retrieving the article directory
    func deleteProduct(pid: String, completion: @escaping (_ error: String?) -> ()) {
        self.db.collection("t_product").document(pid).delete(completion: { (error) in
            if let error = error{
                completion(error.localizedDescription)
            }else{
                completion(nil)
            }
        })
    }//End of deleteProduct func
    
    //Function for retrieving information about an article according to user, article id etc.
    func getProducts(completion: @escaping (_ error: String?, _ products: [t_product]?) -> ()) {
        self.db.collection("t_product").whereField("fkUser", isEqualTo: StaticLinker.user.idUser).addSnapshotListener { (snap, error) in
            if let error = error{
                completion(error.localizedDescription, nil)
            }else if let snap = snap{
                var products = [t_product]()
                for i in snap.documents{
                    products.append(t_product(data: i.data(), id: i.documentID))
                }
                completion(nil, products)
            }else{
                completion(nil, nil)
            }
        }
    }//End of getProducts func
    
    //Function for adding an article, importing an image, converts the image into a url link into a string which will be stored in the database and the management of potential errors
    func addProduct(product: t_product, image: UIImage?, completion: @escaping (_ error: String?) -> ()) {
        let ref = self.db.collection("t_product").document()
        if let img = image{
            self.uploadImage(pid: ref.documentID, image:img, completion: {(error,url) in
                if let err = error{
                    completion(err)
                }else if let Url = url{
                    var product = product
                    product.proPicture = Url.absoluteString
                    ref.setData(product.json) { (error) in
                        if let error = error{
                            completion(error.localizedDescription)
                        }else{
                            completion(nil)
                        }
                    }
                }
            })
        }else{
            ref.setData(product.json) { (error) in
                if let error = error{
                    completion(error.localizedDescription)
                }else{
                    completion(nil)
                }
            }
        }
    }//End of addProducts
    
    //Function for modifying an article, retrieving information of the stored item, retrieving the image via URL
    func editProduct(product: t_product, image: UIImage?, completion: @escaping (_ error: String?, _ product: t_product?) -> ()) {
        let ref = self.db.collection("t_product").document()
        if let img = image{
            self.uploadImage(pid: ref.documentID, image:img, completion: {(error,url) in
                if let error = error{
                    completion(error, nil)
                }else if let Url = url{
                    var product = product
                    product.proPicture = Url.absoluteString
                    self.db.collection("t_product").document(product.idProduct).setData(product.json) { (error) in
                        if let error = error{
                            completion(error.localizedDescription, nil)
                        }else{
                            completion(nil, product)
                        }
                    }
                }
            })
        }else{
            self.db.collection("t_product").document(product.idProduct).setData(product.json) { (error) in
                if let error = error{
                    completion(error.localizedDescription, nil)
                }else{
                    completion(nil, product)
                }
            }
        }
    }//End of editProduct
    
    // Function for importing an image, compressing the image to store it on Firestore, indicates the storage directory corresponding to the user
    private func uploadImage(pid: String, image:UIImage?, completion: @escaping (_ error: String?,_ url:URL?) -> ()){
        let data = image!.jpegData(compressionQuality: 0.2)
        let ref = self.db.collection("t_user").document()
        let imageUpload = Storage.storage().reference().child("ProductImages/\(ref.documentID)/profilePic.jpg")
        _ = imageUpload.putData(data!, metadata: nil) { (metadata, error) in
            if let err = error {
                completion(err.localizedDescription,nil)
            }else{
                imageUpload.downloadURL(completion: { (url, error) in
                    if let err = error {
                        completion(err.localizedDescription,nil)
                    }else{
                        completion(nil,url)
                    }
                })
            }
        }
    }//End of uploadImage

}//Enf of DataServices Class
