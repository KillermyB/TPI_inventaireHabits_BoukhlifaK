//
//  UserServices.swift
//  Inventaire Habits
//
//ETML
//Auteur : Boukhlifa Killermy
//Date   : 12.05.2021
//Description : Récupération des informations de Firebase concernant l'utilisateur, lien avec la base de données
//Copyright © 2021 Killermy Boukhlifa. All rights reserved.

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class UserServices{
    
    private let db = Firestore.firestore()
    static let shared = UserServices()

    private init(){}
    
    func signIn(email:String, password:String, completion: @escaping (_ error: String?) -> ()) {
        Auth.auth().signIn(withEmail: email, password: password, completion: {(user,error) in
            if let error = error{
                completion(error.localizedDescription)
            }else{
                if let error = error{
                    completion(error.localizedDescription)
                }else{
                    //Getting the user object from firebase and saving it to the static global variable in the
                    //static linker class
                    self.db.collection("t_user").document(Auth.auth().currentUser!.uid).getDocument { (snap, error) in
                        if let data = snap?.data(), let uid = snap?.documentID{
                            let user = t_user(data: data, uid: uid)
                            StaticLinker.user = user
                            completion(nil)
                        }else{
                            completion("Une erreur est survenue. Impossible de vous connecter")
                        }
                    }
                }
            }
        })
    }
    //Function for the register of a new user. Get date : user, email, password and profile picture.
    func register(user: t_user, email: String, password:String, image:UIImage?, completion: @escaping (_ error: String?) -> ()){
        //Create the user in Firebase by first checking the following errors
        Auth.auth().createUser(withEmail: email, password: password, completion: {(_user, error) in
            if let error = error{
                completion(error.localizedDescription)
            }else{
                let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.commitChanges(completion: {(error) in
                    if let _ = error{
                        completion(nil)
                    }else{
                        self.createUser(user: user, image: image, completion: {(error) in
                            if let error = error{
                                completion(error)
                            }else{
                                self.getUser(uid: Auth.auth().currentUser!.uid) { (error, user) in
                                    if let error = error{
                                        completion(error)
                                    }else{
                                        //Register in the static linker class
                                        StaticLinker.user = user
                                    }
                                }
                                completion(nil)
                            }
                        })
                    }
                })
            }
        })
    }//End of the function register
    
    //getting the user uid from db
    func getUser(uid:String, completion: @escaping (_ error: String? , _ user: t_user?) -> ()){
        db.collection("t_user").document(uid).getDocument { (snapShot, error) in
            if let err = error{
                completion(err.localizedDescription,nil)
            }else if let data = snapShot?.data(){
                completion(nil, t_user(data: data, uid: Auth.auth().currentUser!.uid))
            }
        }
    }//End of the getUser func
    
    //User creation function in the database
    private func createUser(user: t_user, image:UIImage?, completion: @escaping (_ error: String?) -> ()){
        if let img = image{
            self.uploadProfileImage(image:img, completion: {(error,url) in
                if let err = error{
                    completion(err)
                }else if let Url = url{
                    var user = user
                    user.useProfilePicture = Url.absoluteString
                    self.db.collection("t_user").document(Auth.auth().currentUser!.uid).setData(user.json, completion: {(error) in
                        if let err = error{
                            completion(err.localizedDescription)
                        }else{
                            completion(nil)
                        }
                    })
                }
            })
        }else{
            self.db.collection("t_user").document(Auth.auth().currentUser!.uid).setData(user.json, completion: {(error) in
                if let err = error{
                    completion(err.localizedDescription)
                }else{
                    completion(nil)
                }
            })
        }
    }//End of createUser
    
    //Function for the forgotten password, check that the email address entered by the user corresponds to an account
    func resetPassword(email:String, completion: @escaping (_ error: String?) -> ()){
        Auth.auth().sendPasswordReset(withEmail: email, completion: {(error) in
            if let err = error{
                completion(err.localizedDescription)
            }else{
                completion(nil)
            }
        })
    }//End of resetPassword
    
    //Function for changing a profile photo, if the profile photo already exists then it is replaced by a new one otherwise the UploadImage function is used
    func changeProfileImage(image: UIImage, completion: @escaping (_ error: String?) -> ()){
        self.uploadProfileImage(image: image , completion: {(error,url) in
            if let err = error{
                completion(err)
            }else if let Url = url{
                var user = StaticLinker.user!
                user.useProfilePicture = Url.absoluteString
                user.idUser = Auth.auth().currentUser!.uid
                self.db.collection("t_user").document(Auth.auth().currentUser!.uid).setData(user.json, completion: {(error) in
                    if let err = error{
                        completion(err.localizedDescription)
                    }else{
                        StaticLinker.user = user
                        completion(nil)
                    }
                })
            }
        })
    }//End of changeProfileImage
    
    // Function for importing an image, compressing the image to store it on Firestore, indicates the storage directory corresponding to the user
    private func uploadProfileImage(image:UIImage?, completion: @escaping (_ error: String?,_ url:URL?) -> ()){
        let data = image!.jpegData(compressionQuality: 0.2)
        let ref = self.db.collection("t_user").document()
        let imageUpload = Storage.storage().reference().child("Images/\(ref.documentID)/profilePic.jpg")
        _ = imageUpload.putData(data!, metadata: nil) { (metadata, error) in
            if let err = error {
                completion(err.localizedDescription,nil)
            }else{
                imageUpload.downloadURL(completion: { (url, error) in
                    if let err = error {
                        completion(err.localizedDescription,nil)
                    }else{
                        completion(nil,url)
                    }
                })
            }
        }
    }//End of uploadProfileImage
    
}//End of UserServices Class
