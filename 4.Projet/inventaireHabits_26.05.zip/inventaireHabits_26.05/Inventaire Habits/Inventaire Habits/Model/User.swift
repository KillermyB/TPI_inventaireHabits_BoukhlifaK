//
//  User.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/9/21.
//

import Foundation

struct t_user{
    
    var idUser = ""
    var useName: String
    var useEmail: String
    var useProfilePicture: String
    
    var json: [String: Any] {
      return [
        "useName": self.useName,
        "useEmail": self.useEmail,
        "useProfilePicture": self.useProfilePicture
      ]
    }
    
    init(useName: String, useEmail: String, useProfilePicture: String){
        self.useName = useName
        self.useEmail = useEmail
        self.useProfilePicture = useProfilePicture
    }
    
    init(data: [String: Any], uid: String){
        self.idUser = uid
        self.useName = data["useName"] as! String
        self.useEmail = data["useEmail"] as! String
        self.useProfilePicture = data["useProfilePicture"] as! String
    }
}
