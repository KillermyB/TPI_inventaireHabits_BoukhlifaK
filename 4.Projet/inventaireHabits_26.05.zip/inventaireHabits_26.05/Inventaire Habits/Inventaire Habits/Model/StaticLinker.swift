//
//  StaticLinker.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/9/21.
//

import Foundation

class StaticLinker{
    
    static var user: t_user!
    static var products: [t_product]!
    
}
