//
//  LaunchViewController.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/8/21.
//

import UIKit
import FirebaseAuth
import MBProgressHUD

class LaunchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.setup()
    }
    
    private func setup(){
        if Auth.auth().currentUser == nil{
            self.performSegue(withIdentifier: "login", sender: nil)
        }else{
            MBProgressHUD.showAdded(to: self.view, animated: true)
            UserServices.shared.getUser(uid: Auth.auth().currentUser!.uid) { (error, user) in
                if let error = error{
                    self.showAlert(title: "Error", message: error) { (_) in
                        self.performSegue(withIdentifier: "login", sender: nil)
                    }
                }else if let user = user{
                    StaticLinker.user = user
                    self.performSegue(withIdentifier: "home", sender: nil)
                }else{
                    self.showAlert(title: "Error", message: "User not found") { (_) in
                        self.performSegue(withIdentifier: "login", sender: nil)
                    }
                }
            }
        }
    }

}
