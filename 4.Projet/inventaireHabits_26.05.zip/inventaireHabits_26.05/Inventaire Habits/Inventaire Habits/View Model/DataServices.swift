//
//  DataServices.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/9/21.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class DataServices{
    
    private let db = Firestore.firestore()
    static let shared = DataServices()

    private init(){}
    
    func deleteProduct(pid: String, completion: @escaping (_ error: String?) -> ()) {
        self.db.collection("t_product").document(pid).delete(completion: { (error) in
            if let error = error{
                completion(error.localizedDescription)
            }else{
                completion(nil)
            }
        })
    }
    
    func getProducts(completion: @escaping (_ error: String?, _ products: [t_product]?) -> ()) {
        self.db.collection("t_product").whereField("fkUser", isEqualTo: StaticLinker.user.idUser).addSnapshotListener { (snap, error) in
            if let error = error{
                completion(error.localizedDescription, nil)
            }else if let snap = snap{
                var products = [t_product]()
                for i in snap.documents{
                    products.append(t_product(data: i.data(), id: i.documentID))
                }
                completion(nil, products)
            }else{
                completion(nil, nil)
            }
        }
    }
    
    func addProduct(product: t_product, image: UIImage?, completion: @escaping (_ error: String?) -> ()) {
        let ref = self.db.collection("t_product").document()
        if let img = image{
            self.uploadImage(pid: ref.documentID, image:img, completion: {(error,url) in
                if let err = error{
                    completion(err)
                }else if let Url = url{
                    var product = product
                    product.proPicture = Url.absoluteString
                    ref.setData(product.json) { (error) in
                        if let error = error{
                            completion(error.localizedDescription)
                        }else{
                            completion(nil)
                        }
                    }
                }
            })
        }else{
            ref.setData(product.json) { (error) in
                if let error = error{
                    completion(error.localizedDescription)
                }else{
                    completion(nil)
                }
            }
        }
    }
    
    func editProduct(product: t_product, image: UIImage?, completion: @escaping (_ error: String?, _ product: t_product?) -> ()) {
        let ref = self.db.collection("t_product").document()
        if let img = image{
            self.uploadImage(pid: ref.documentID, image:img, completion: {(error,url) in
                if let error = error{
                    completion(error, nil)
                }else if let Url = url{
                    var product = product
                    product.proPicture = Url.absoluteString
                    self.db.collection("t_product").document(product.idProduct).setData(product.json) { (error) in
                        if let error = error{
                            completion(error.localizedDescription, nil)
                        }else{
                            completion(nil, product)
                        }
                    }
                }
            })
        }else{
            self.db.collection("t_product").document(product.idProduct).setData(product.json) { (error) in
                if let error = error{
                    completion(error.localizedDescription, nil)
                }else{
                    completion(nil, product)
                }
            }
        }
    }
    
    private func uploadImage(pid: String, image:UIImage?, completion: @escaping (_ error: String?,_ url:URL?) -> ()){
        let data = image!.jpegData(compressionQuality: 0.2)
        let ref = self.db.collection("t_user").document()
        let imageUpload = Storage.storage().reference().child("ProductImages/\(ref.documentID)/profilePic.jpg")
        _ = imageUpload.putData(data!, metadata: nil) { (metadata, error) in
            if let err = error {
                completion(err.localizedDescription,nil)
            }else{
                imageUpload.downloadURL(completion: { (url, error) in
                    if let err = error {
                        completion(err.localizedDescription,nil)
                    }else{
                        completion(nil,url)
                    }
                })
            }
        }
    }

}
