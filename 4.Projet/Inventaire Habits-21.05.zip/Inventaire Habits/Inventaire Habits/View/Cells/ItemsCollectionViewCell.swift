//
//  ItemsCollectionViewCell.swift
//  Inventaire Habits
//
//  Created by Killermy Boukhlifa on 5/8/21.
//

import UIKit

class ItemsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var selectImg: UIImageView!
    @IBOutlet weak var img: RoundableImageView!
    @IBOutlet weak var lbl: UILabel!
    
}
