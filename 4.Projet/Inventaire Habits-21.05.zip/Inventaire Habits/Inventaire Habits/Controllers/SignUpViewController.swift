//
//  SignUpViewController.swift
//  Inventaire Habits
//
//  Crée par Killermy Boukhlifa on 19/05/21.
//

import UIKit
import MBProgressHUD
import MobileCoreServices

class SignUpViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var img: RoundableImageView!
    @IBOutlet weak var name: DesignableUITextField!
    @IBOutlet weak var email: DesignableUITextField!
    @IBOutlet weak var password: DesignableUITextField!
    
    private var image: UIImage!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func signUp(_ sender: Any) {
        if let email = self.email.text, let password = self.password.text, let name = self.name.text{
            if email != "" && password != ""{
                MBProgressHUD.showAdded(to: self.view, animated: true)
                UserServices.shared.register(user: t_user(useName: name, useEmail: email, useProfilePicture: ""), email: email, password: password, image: self.image){ (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Error", message: error) { (_) in }
                    }else{
                        self.showAlert(title: "Success", message: "Your account has been created") { (_) in
                            self.performSegue(withIdentifier: "home", sender: nil)
                        }
                    }
                }
            }else{
                self.showAlert(title: "Error", message: "Please fill all fields") { (_) in }
            }
        }
    }
    
    @IBAction func selectImage(_ sender: Any) {
        let optionMenu = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let galleryAction = UIAlertAction(title: "Gallery", style: .default, handler: {action in
            self.library()
        })
        let cameraAction = UIAlertAction(title: "Camera", style: .default, handler: {action in
            self.camera()
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {action in
        })
        optionMenu.addAction(galleryAction)
        optionMenu.addAction(cameraAction)
        optionMenu.addAction(cancelAction)
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = optionMenu.popoverPresentationController {
                popoverController.sourceView = self.view
                popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
                popoverController.permittedArrowDirections = []
            }
        }
        self.present(optionMenu, animated: true, completion: nil)
    }
    
    private func camera(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .camera
        imgPicker.allowsEditing = true
        self.present(imgPicker, animated: true, completion: nil)
    }
    
    private func library(){
        self.image = nil
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.mediaTypes = [(kUTTypeImage as String)]
        imgPicker.sourceType = .photoLibrary
        imgPicker.allowsEditing = true
        self.present(imgPicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            self.image = image
            self.img.image = image
            self.img.contentMode = .scaleAspectFill
            self.dismiss(animated: true, completion: nil)
        }
    }
        
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

}
