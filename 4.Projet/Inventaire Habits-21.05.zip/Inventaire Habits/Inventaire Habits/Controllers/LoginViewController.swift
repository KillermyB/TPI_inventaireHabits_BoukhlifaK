//
//  LoginViewController.swift
//  Inventaire Habits
//
//  Crée par Killermy Boukhlifa on 19/05/21.
//

import UIKit
import MBProgressHUD

class LoginViewController: UIViewController {

    @IBOutlet weak var email: DesignableUITextField!
    @IBOutlet weak var password: DesignableUITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func login(_ sender: Any) {
        if let email = self.email.text, let password = self.password.text{
            if email != "" && password != ""{
                MBProgressHUD.showAdded(to: self.view, animated: true)
                UserServices.shared.signIn(email: email, password: password) { (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Error", message: error) { (_) in }
                    }else{
                        self.performSegue(withIdentifier: "home", sender: nil)
                    }
                }
            }else{
                self.showAlert(title: "Error", message: "Please fill all fields") { (_) in }
            }
        }
    }

}
