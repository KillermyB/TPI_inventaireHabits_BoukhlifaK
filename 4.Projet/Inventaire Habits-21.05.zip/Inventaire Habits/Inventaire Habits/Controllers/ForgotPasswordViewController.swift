//
//  ForgotPasswordViewController.swift
//  Inventaire Habits
//
//  Crée par Killermy Boukhlifa on 18/05/21.
//

import UIKit
import MBProgressHUD

class ForgotPasswordViewController: UIViewController {

    @IBOutlet weak var email: DesignableUITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func reset(_ sender: Any) {
        if let email = self.email.text{
            if email != "" {
                MBProgressHUD.showAdded(to: self.view, animated: true)
                UserServices.shared.resetPassword(email: email) { (error) in
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let error = error{
                        self.showAlert(title: "Error", message: error) { (_) in }
                    }else{
                        self.showAlert(title: "Success", message: "Please check your email for password reset link") { (_) in
                            self.navigationController?.popViewController(animated: true)
                        }
                    }
                }
            }else{
                self.showAlert(title: "Error", message: "Please provide an email associated with your account") { (_) in }
            }
        }
    }
    
}
